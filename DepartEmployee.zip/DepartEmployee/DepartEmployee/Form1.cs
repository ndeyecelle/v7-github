﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DepartEmployee
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void reportToolStripMenuItem1_Click(object sender, EventArgs e)
        {

        }

        private void cRUDCLASSEToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Formdepartement fr = new Formdepartement();
            fr.Show();
        }

        private void cRUDETUDIANTToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Formemployee fr = new Formemployee();
            fr.Show();
        }

        private void eTUDIANTToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Formdepartement fr = new Formdepartement();
            fr.Show();
        }

        private void fermerToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void cLASSEToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Formemployee fr = new Formemployee();
            fr.Show();
        }
    }
}
