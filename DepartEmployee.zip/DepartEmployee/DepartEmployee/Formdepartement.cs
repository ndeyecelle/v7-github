﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.Remoting.Contexts;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ToolTip;

namespace DepartEmployee
{
    public partial class Formdepartement : Form

         
    {
        gestion_employeeEntities context = new gestion_employeeEntities();
        public Formdepartement()
        {
            InitializeComponent();
        }

        private void btndepartement_Click(object sender, EventArgs e)
        {
            departement c = new departement();
            c.libelle = cmbiddep.Text + cmblibelledep.Text;
            c.libelledep = cmblibelledep.Text;
            c.libelledep = cmblibelledep.Text;

            context.departement.Add(c);
            context.SaveChanges();

            MessageBox.Show("classe enregistrer");
            datadepartement.DataSource = context.departement.ToList();
        
    }
    }
}
