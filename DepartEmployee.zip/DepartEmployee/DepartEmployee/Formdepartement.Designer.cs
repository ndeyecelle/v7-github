﻿namespace DepartEmployee
{
    partial class Formdepartement
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.btndepartement = new System.Windows.Forms.Button();
            this.cmbiddep = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.datadepartement = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.cmblibelledep = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.datadepartement)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.SeaGreen;
            this.panel1.Controls.Add(this.btndepartement);
            this.panel1.Controls.Add(this.cmbiddep);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.datadepartement);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.cmblibelledep);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Location = new System.Drawing.Point(-8, -20);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(575, 400);
            this.panel1.TabIndex = 7;
            // 
            // btndepartement
            // 
            this.btndepartement.BackColor = System.Drawing.Color.LawnGreen;
            this.btndepartement.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btndepartement.Location = new System.Drawing.Point(159, 178);
            this.btndepartement.Name = "btndepartement";
            this.btndepartement.Size = new System.Drawing.Size(108, 28);
            this.btndepartement.TabIndex = 17;
            this.btndepartement.Text = "Enregistrer";
            this.btndepartement.UseVisualStyleBackColor = false;
            this.btndepartement.Click += new System.EventHandler(this.btndepartement_Click);
            // 
            // cmbiddep
            // 
            this.cmbiddep.FormattingEnabled = true;
            this.cmbiddep.Items.AddRange(new object[] {
            "Departement de bembey",
            "Departement de diourbel",
            "Departement de mbacke"});
            this.cmbiddep.Location = new System.Drawing.Point(139, 85);
            this.cmbiddep.Name = "cmbiddep";
            this.cmbiddep.Size = new System.Drawing.Size(160, 21);
            this.cmbiddep.TabIndex = 7;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(161, 24);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(156, 15);
            this.label3.TabIndex = 6;
            this.label3.Text = "AJOUT DEPARTEMENT";
            // 
            // datadepartement
            // 
            this.datadepartement.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.datadepartement.Location = new System.Drawing.Point(17, 212);
            this.datadepartement.Name = "datadepartement";
            this.datadepartement.Size = new System.Drawing.Size(382, 165);
            this.datadepartement.TabIndex = 5;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(30, 86);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(49, 15);
            this.label1.TabIndex = 2;
            this.label1.Text = "IDDEP";
            // 
            // cmblibelledep
            // 
            this.cmblibelledep.FormattingEnabled = true;
            this.cmblibelledep.Items.AddRange(new object[] {
            "VILLE DE NAISSANCE",
            "DEPARTEMENT DE RESIDENCE"});
            this.cmblibelledep.Location = new System.Drawing.Point(139, 141);
            this.cmblibelledep.Name = "cmblibelledep";
            this.cmblibelledep.Size = new System.Drawing.Size(160, 21);
            this.cmblibelledep.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(30, 141);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(90, 15);
            this.label2.TabIndex = 3;
            this.label2.Text = "LIBELLEDEP";
            // 
            // Formdepartement
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(559, 361);
            this.Controls.Add(this.panel1);
            this.Name = "Formdepartement";
            this.Text = "Formdepartement";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.datadepartement)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btndepartement;
        private System.Windows.Forms.ComboBox cmbiddep;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.DataGridView datadepartement;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cmblibelledep;
        private System.Windows.Forms.Label label2;
    }
}