﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.Remoting.Contexts;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DepartEmployee
{
    public partial class Formemployee : Form
    {
        gestion_employeeEntities context =new gestion_employeeEntities();

        public static List<departement> DataSource { get; private set; }
        public static string DisplayMember { get; private set; }
        public static string ValueMember { get; private set; }

        public Formemployee()
        {
            InitializeComponent();
            
           Formemployee .DataSource = context.departement.ToList();
            Formemployee.DisplayMember = "libelle";
           Formemployee.ValueMember = "id";
            dataemployee.DataSource = context.employee.ToList();
        }

        private void btnmodifier_Click(object sender, EventArgs e)
        {
            int idEtudiant;
            if (int.TryParse(txtid.Text, out idEtudiant))
            {
                var et = context.employee.FirstOrDefault(etudiant => etudiant.iddepartement== idEtudiant);


                if (et != null)
                {
                    et.prenomemp = txtprenom.Text;
                    et.nomemp = txtnom.Text;

                    et.fonction = txtfonction.Text;
                    et.iddepartement = Convert.ToInt32(cmbclasse.SelectedValue);

                    context.SaveChanges();
                    MessageBox.Show("employee modifié");
                }
                else
                {
                    MessageBox.Show("employee introuvable");
                }


                dataemployee.DataSource = context.employee.ToList();
            }
            else
            {
                MessageBox.Show("ID invalide");
            }

        }

        private void cmbclasse_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btnetudiant_Click(object sender, EventArgs e)
        {
            employee et = new employee();
            et.prenomemp = txtprenom.Text;
            et.nomemp = txtnom.Text;
           
            
            et.iddepartement = Convert.ToInt32(cmbclasse.SelectedValue);
            context.employee.Add(et);
            context.SaveChanges();
            MessageBox.Show("employee enreristrer");
            dataemployee.DataSource = context.employee.ToList();
        }

        private void btnannuler_Click(object sender, EventArgs e)
        {
            txtprenom.Text = "";
            txtnom.Text = "";
            txtfonction.Text = "";
            txtsalaire.Text = "";
            
        }

        private void btnsupprimer_Click(object sender, EventArgs e)
        {
            if (dataemployee.SelectedRows.Count > 0)
            {

                int idEtudiant = (int)dataemployee.SelectedRows[0].Cells["id"].Value;


                var et = context.employee.FirstOrDefault(etudiant => etudiant.idemp == idEtudiant);

                if (et != null)
                {
                    context.employee.Remove(et);
                    context.SaveChanges();
                    MessageBox.Show("employee supprimé");
                }
                else
                {
                    MessageBox.Show("employee introuvable");
                }


                dataemployee.DataSource = context.employee.ToList();
            }
            else
            {
                MessageBox.Show("Aucun employee sélectionné");
            }
        }
    }
    }



